
"use client";

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShoppingCart, Globe } from "lucide-react";
import { motion } from "framer-motion";
import Image from "next/image";

const productos = [
  {
    id: 1,
    nombre: {
      es: "Zapatillas Puma",
      en: "Puma Sneakers",
    },
    descripcion: {
      es: "Diseño urbano y cómodo para cualquier ocasión.",
      en: "Urban and comfortable design for any occasion.",
    },
    precio: 80,
    imagen: "/puma-zapatillas.jpg",
  },
  {
    id: 2,
    nombre: {
      es: "Cadenas",
      en: "Chains",
    },
    descripcion: {
      es: "Cadenas elegantes y modernas con acabados premium.",
      en: "Elegant urban chains with premium finishes.",
    },
    precio: 50,
    imagen: "/mockup-cadena.jpg",
  },
  {
    id: 3,
    nombre: {
      es: "Relojes",
      en: "Watches",
    },
    descripcion: {
      es: "Relojes con estilo para complementar tu outfit.",
      en: "Stylish watches to complement your outfit.",
    },
    precio: 90,
    imagen: "/mockup-reloj.jpg",
  },
];

export default function SketitShop() {
  const [idioma, setIdioma] = useState("es");
  const [carrito, setCarrito] = useState([]);

  const agregarAlCarrito = (producto) => {
    setCarrito((prev) => [...prev, producto]);
  };

  const total = carrito.reduce((acc, prod) => acc + prod.precio, 0);

  return (
    <div className="bg-neutral-100 min-h-screen text-neutral-900">
      <header className="bg-white shadow-md p-4 flex justify-between items-center">
        <motion.div
          className="flex items-center gap-4"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Image src="/logo-sketit.png" alt="SKETIT SHOP" width={40} height={40} />
          <h1 className="text-2xl font-bold tracking-tight">SKETIT SHOP</h1>
        </motion.div>
        <div className="flex gap-4 items-center">
          <Button variant="outline" onClick={() => setIdioma(idioma === "es" ? "en" : "es") }>
            <Globe className="mr-2 h-4 w-4" /> {idioma === "es" ? "EN" : "ES"}
          </Button>
          <Button>
            <ShoppingCart className="mr-2 h-4 w-4" /> {idioma === "es" ? "Carrito" : "Cart"} ({carrito.length})
          </Button>
        </div>
      </header>

      <main className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        {productos.map((producto) => (
          <Card key={producto.id} className="rounded-2xl shadow-lg">
            <CardContent className="p-4 text-center">
              <Image
                src={producto.imagen}
                alt={producto.nombre[idioma]}
                width={300}
                height={200}
                className="mx-auto rounded-xl"
              />
              <h2 className="text-xl font-semibold mt-4">{producto.nombre[idioma]}</h2>
              <p className="text-sm text-neutral-600">{producto.descripcion[idioma]}</p>
              <p className="font-bold mt-2">${producto.precio}</p>
              <Button onClick={() => agregarAlCarrito(producto)} className="mt-4 w-full">
                {idioma === "es" ? "Agregar al carrito" : "Add to Cart"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </main>

      <section className="p-6 bg-white mt-8 rounded-2xl shadow-inner">
        <h3 className="text-xl font-semibold mb-4 text-center">
          {idioma === "es" ? "Resumen del carrito" : "Cart Summary"}
        </h3>
        {carrito.length === 0 ? (
          <p className="text-center text-neutral-500">
            {idioma === "es" ? "Tu carrito está vacío." : "Your cart is empty."}
          </p>
        ) : (
          <ul className="text-center">
            {carrito.map((prod, i) => (
              <li key={i} className="text-sm">
                {prod.nombre[idioma]} - ${prod.precio}
              </li>
            ))}
            <p className="font-bold mt-2">
              {idioma === "es" ? "Total" : "Total"}: ${total}
            </p>
            <div className="mt-4 space-y-2">
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                {idioma === "es" ? "Pagar con PayPal" : "Pay with PayPal"}
              </Button>
              <div className="text-sm text-neutral-700">
                <p>
                  <strong>{idioma === "es" ? "Banco Pichincha" : "Bank Transfer"}:</strong> 0123456789 a nombre de Sketit Shop
                </p>
                <p>
                  <strong>Binance (USDT):</strong> 0x1234567890abcdef... <br />
                  {idioma === "es" ? "Enviar captura del pago por DM." : "Send payment proof via DM."}
                </p>
              </div>
            </div>
          </ul>
        )}
      </section>

      <footer className="bg-white shadow-inner p-4 text-center text-sm text-neutral-500 mt-8">
        © 2025 SKETIT SHOP. {idioma === "es" ? "Todos los derechos reservados." : "All rights reserved."}
      </footer>
    </div>
  );
}
